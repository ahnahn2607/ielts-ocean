// IELTS Ocean: tự điền link + transcript vào form "Tạo bài dictation".
(() => {
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  async function fill(p) {
    if (!p || Date.now() - p.at > 10 * 60 * 1000) return;
    // đợi form có trong trang
    let url = null;
    for (let i = 0; i < 120 && !(url = document.getElementById('dUrl')); i++) await wait(500);
    if (!url) return;
    if (location.hash !== '#dictation') location.hash = '#dictation';
    const set = (id, v) => { const el = document.getElementById(id); if (!el) return; el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); };
    set('dUrl', 'https://www.youtube.com/watch?v=' + p.videoId);
    set('dTitle', p.title || '');
    set('dText', p.text);
    await chrome.storage.local.remove('ioPending');
    const box = document.getElementById('dText');
    const note = document.createElement('p');
    note.className = 'small';
    note.style.cssText = 'color:#8be3b4;margin:8px 0 0';
    note.textContent = 'Tiện ích đã điền sẵn transcript từ YouTube' + (p.track ? ' (' + p.track + ')' : '') + '. Kiểm tra rồi bấm "Tạo bài".';
    box && box.closest('label') && box.closest('label').after(note);
    const app = document.getElementById('app');
    for (let i = 0; i < 16 && app && app.hidden; i++) await wait(500);
    if (app && app.hidden) {
      note.textContent += ' Bạn cần đăng nhập (hoặc dùng thử) trước, transcript vẫn được giữ.';
    }
    (document.getElementById('dCreate') || box).scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  chrome.storage.local.get('ioPending').then((r) => fill(r.ioPending));
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.ioPending && ch.ioPending.newValue) fill(ch.ioPending.newValue); });
})();
