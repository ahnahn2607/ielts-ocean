// Mở IELTS Ocean ở tab mới khi YouTube gửi transcript sang.
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'io-open') {
    chrome.tabs.create({ url: 'https://ahnahn2607.github.io/ielts-ocean/#dictation' });
  }
});
