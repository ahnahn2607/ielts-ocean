// IELTS Ocean: nút "Gửi sang IELTS Ocean" trên trang xem video YouTube.
// Cách lấy: mở bảng "Hiện bản chép lời" của chính YouTube rồi đọc các dòng (mốc giờ + lời).
(() => {
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const vid = () => new URL(location.href).searchParams.get('v');
  let toastT = null;
  function toast(msg, ms = 6000) {
    let t = document.getElementById('io-toast');
    if (!t) { t = document.createElement('div'); t.id = 'io-toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
    t.textContent = msg; clearTimeout(toastT); toastT = setTimeout(() => t.remove(), ms);
  }
  async function until(fn, timeout = 8000, step = 250) {
    const end = Date.now() + timeout;
    while (Date.now() < end) { const v = fn(); if (v) return v; await wait(step); }
    return null;
  }
  const panelSel = 'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-searchable-transcript"]';
  // YouTube có 2 kiểu giao diện bảng chép lời: cũ (ytd-transcript-segment-renderer) và mới (transcript-segment-view-model)
  const segs = () => document.querySelectorAll('transcript-segment-view-model, ' + panelSel + ' ytd-transcript-segment-renderer');

  async function openPanel() {
    if (segs().length) return true;
    // 1) Nút "Hiện bản chép lời" trong phần mô tả video
    let btn = document.querySelector('ytd-video-description-transcript-section-renderer button');
    if (!btn) {
      const more = document.querySelector('#description-inline-expander #expand, tp-yt-paper-button#expand');
      if (more) { more.click(); await wait(600); }
      btn = await until(() => document.querySelector('ytd-video-description-transcript-section-renderer button'), 3000);
    }
    // 2) Dự phòng: tìm theo chữ trên nút (tiếng Anh / tiếng Việt)
    if (!btn) {
      btn = [...document.querySelectorAll('button, tp-yt-paper-item, yt-button-shape button')]
        .find((b) => /show transcript|hiện bản chép lời|bản chép lời/i.test(b.textContent || b.getAttribute('aria-label') || ''));
    }
    if (!btn) return false;
    btn.click();
    if (await until(() => segs().length, 4000)) return true;
    // giao diện mới: bảng "In this video" có 2 chip Chapters / Transcript
    const chip = [...document.querySelectorAll('chip-view-model, chip-shape, yt-chip-cloud-chip-renderer, button')]
      .find((c) => /^(transcript|bản chép lời)$/i.test((c.textContent || '').trim()));
    if (chip) { (chip.querySelector('button') || chip).click(); }
    return !!(await until(() => segs().length, 8000));
  }

  function collect() {
    const lines = [];
    segs().forEach((s) => {
      const ts = (s.querySelector('.ytwTranscriptSegmentViewModelTimestamp, .segment-timestamp') || {}).textContent || '';
      let tx = (s.querySelector('.segment-text') || {}).textContent || '';
      if (!tx) tx = [...s.querySelectorAll('span.ytAttributedStringHost, yt-formatted-string')].map((e) => e.textContent).join(' ');
      const t = ts.trim(), x = tx.replace(/\s+/g, ' ').trim();
      if (t && x) lines.push(t + '\n' + x);
    });
    return lines.join('\n');
  }
  function trackName() {
    const el = document.querySelector(panelSel + ' #footer yt-dropdown-menu, ' + panelSel + ' yt-sort-filter-sub-menu-renderer');
    return el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
  }

  async function send() {
    const b = document.getElementById('io-send');
    const id = vid(); if (!id) return;
    b.disabled = true; b.lastChild.textContent = 'Đang lấy transcript…';
    try {
      const ok = await openPanel();
      if (!ok) { toast('Video này không có bản chép lời, hoặc YouTube chưa hiện nút "Hiện bản chép lời". Thử tải lại trang rồi bấm lại.'); return; }
      await wait(400);
      const text = collect();
      if (!text) { toast('Chưa đọc được bản chép lời. Thử bấm lại sau vài giây.'); return; }
      const title = (document.querySelector('h1.ytd-watch-metadata yt-formatted-string, h1.title') || {}).textContent || '';
      const track = trackName();
      await chrome.storage.local.set({ ioPending: { videoId: id, title: title.trim(), text, track, at: Date.now() } });
      chrome.runtime.sendMessage({ type: 'io-open' });
      toast('Đã gửi ' + segs().length + ' dòng sang IELTS Ocean' + (track ? ' (' + track + ')' : '') + '. Nếu có lựa chọn ngôn ngữ, nên chọn "English" thay vì "auto-generated" trong bảng chép lời rồi gửi lại.', 9000);
    } catch (e) {
      toast('Có lỗi khi lấy transcript: ' + e.message);
    } finally {
      b.disabled = false; b.lastChild.textContent = 'Gửi sang IELTS Ocean';
    }
  }

  function ensureButton() {
    const onWatch = location.pathname === '/watch' && vid();
    let b = document.getElementById('io-send');
    if (!onWatch) { if (b) b.remove(); return; }
    if (b) return;
    b = document.createElement('button');
    b.id = 'io-send'; b.type = 'button'; b.title = 'Lấy bản chép lời của video này và mở mục Dictation trên IELTS Ocean';
    const img = document.createElement('img'); img.src = chrome.runtime.getURL('icon48.png'); img.alt = '';
    b.append(img, document.createTextNode('Gửi sang IELTS Ocean'));
    b.addEventListener('click', send);
    document.body.appendChild(b);
  }
  ensureButton();
  // YouTube là trang một-trang: theo dõi khi chuyển video
  document.addEventListener('yt-navigate-finish', ensureButton);
  setInterval(ensureButton, 2000);
})();
